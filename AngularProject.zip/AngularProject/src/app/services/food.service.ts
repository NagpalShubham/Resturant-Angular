import { Injectable } from '@angular/core';
import { Foods } from '../shared/model/food';
@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }
  getFoodById(id:number):Foods{
    return this.getAll().find(food =>food.id == id)!;
  }

  getAllFoodByTag(tag:string) :Foods[]{
    if(tag == 'All')
    return this.getAll()
    else
    return this.getAll().filter(food=> food.tags?.includes(tag));
  }
getAll():Foods[]{
  return[
    {
      id:1,
      name:'Waffle',
      cookTime:'15-20',
      price:10,
      favourite:true,
      origins:['belgian','italy'],
      star: 3.3,
      imageUrl:'/assets/food-1.jpg',
      tags: ['FastFood','fry']
},
{
  id:2,
  name:'Green salad',
  cookTime:'15-20',
  price:10,
  favourite:true,
  origins:['italy'],
  star: 4.2,
  imageUrl:'/assets/food-2.jpg',
  tags: ['Italianfood']
},
{
  id:3,
  name:'rice bowl',
  cookTime:'15-20',
  price:10,
  favourite:true,
  origins:['Indian'],
  star: 3.3,
  imageUrl:'/assets/food-3.jpg',
  tags: ['FastFood','fry'],
},
{
  id:4,
  name:'Chicken Salad',
  cookTime:'15-20',
  price:10,
  favourite:true,
  origins:['belgian','italy'],
  star: 3.3,
  imageUrl:'/assets/food-4.jpg',
  tags: ['FastFood','fry'],
},
{
  id:5,
  name:'burgers',
  cookTime:'15-20',
  price:10,
  favourite:true,
  origins:['belgian','italy'],
  star: 3.3,
  imageUrl:'/assets/food-2.jpg',
  tags: ['FastFood','fry'],
},
{
  id:6,
  name:'Happy Meal',
  cookTime:'15-20',
  price:10,
  favourite:true,
  origins:['belgian','italy'],
  star: 3.3,
  imageUrl:'/assets/food-5.jpg',
  tags: ['FastFood','fry'],
}
   
  ];
}

}


