import { Injectable } from '@angular/core';
import { Cart } from '../shared/model/Cart';
import { Foods } from '../shared/model/food';
import { CartItem } from '../shared/model/cartitem';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart:Cart = new Cart();

  addToCart(food:Foods){
    console.log(food+" inside serv food displayed");
    
     let CartItem = this.cart.items.find(item => item.food.id == food.id)
     console.log(CartItem+" inside service Mtd");
    
     if (CartItem){
       this.changeQuantity(food.id , CartItem.quantity +1)
      
      return;
    }
  //  this.cart.items.push(new CartItem(food));
  }
  removeFromCart(foodId:number):void{
    this.cart.items = this.cart.items.filter(item =>item.food.id !=foodId)
  }
  changeQuantity(quantity:number , foodId:number){
    let cartItem = this.cart.items.find(item=>item.food.id == foodId);
    if(!cartItem) return;
    cartItem.quantity = quantity;
  }
  getCart():Cart{
    console.log(this.cart);
    
    return this.cart;
  }
}
