import { Component } from '@angular/core';

@Component({
  selector: 'app-resturantname',
  templateUrl: './resturantname.component.html',
  styleUrls: ['./resturantname.component.css']
})
export class ResturantnameComponent {

}
