export class Foods{
    id!:number;
    price!:number;
    name!:string;
    favourite:boolean=false;
    star!:number;
    tags?:string[];
    imageUrl!:string;
    cookTime!:string;
    origins!:string[];
}